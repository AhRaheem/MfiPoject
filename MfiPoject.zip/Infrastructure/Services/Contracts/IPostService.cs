﻿namespace Infrastructure.Services.Contracts
{
	//public interface IPostService
	//{
	//	Task<bool> Create(PostCreateDto Dto);

	//	Task<bool> Update(PostUpdateDto Dto);

	//	Task<bool> Delete(string Id);

	//	Task<PaginatedList<PostDto>> GetAll(PostType PostType, string q= "", int page = 0, int size = 10);

	//	Task<PostDto> GetById(string Id);
 //       Task<PostDto> GetByArName(string Name);
 //       Task<PostDto> GetByEnName(string Name);
 //       Task<PostDto> GetByIdWithAffiliateLaws(string Id);
	//	Task<PostDto> GetByIdWithParagraphs(string Id);

 //       Task<PostUpdateDto> GetUpdateInfo(string Id);
 //       Task<PostDto> GetDetails(string Id);
 //       Task<bool> Publish(string Id);
 //       Task<bool> Reject(PostRejectDto postRejectDto);


 //       Task<bool> CreatePostParagraph(PostParagraphCreateDto Dto);

 //       Task<bool> UpdatePostParagraph(PostParagraphUpdateDto Dto);

 //       Task<bool> DeletePostParagraph(string Id);

 //       Task<bool> SortPostParagraphs(List<SortModel> Dtos);

 //       Task<IEnumerable<PostParagraphDto>> GetParagraphs(string PostId);

 //       Task<PostParagraphDto> GetParagraph(string Id);
 //       Task<PostParagraphDto> GetParagraphByArName(string Name);
 //       Task<PostParagraphDto> GetParagraphByEnName(string Name);

 //       Task<PostParagraphUpdateDto> GetParagraphUpdateInfo(string Id);



 //       Task<bool> CreatePostAffiliateLaw(PostAffiliateLawCreateDto Dto);

 //       Task<bool> UpdatePostAffiliateLaw(PostAffiliateLawUpdateDto Dto);

 //       Task<bool> DeletePostAffiliateLaw(string Id);

 //       Task<bool> SortPostAffiliateLaws(List<SortModel> Dtos);

 //       Task<IEnumerable<PostAffiliateLawDto>> GetAffiliateLaws(string PostId);

 //       Task<PostAffiliateLawDto> GetAffiliateLaw(string Id);
 //       Task<PostAffiliateLawDto> GetAffiliateLawByArName(string Name);
 //       Task<PostAffiliateLawDto> GetAffiliateLawByEnName(string Name);

 //       Task<PostAffiliateLawUpdateDto> GetAffiliateLawUpdateInfo(string Id);

 //   }
}
