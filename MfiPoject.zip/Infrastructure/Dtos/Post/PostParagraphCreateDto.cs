﻿

namespace Infrastructure.Dtos.Post
{
    //public class PostParagraphCreateDto : IMapFrom<PostArticlePostParagraph>
    //{
    //    [TranslateDisplay("Arabic Title")]
    //    public string? TitleAr { get; set; }
    //    [TranslateDisplay("English Title")]
    //    public string? TitleEn { get; set; }
    //    [TranslateDisplay("Arabic Content")]
    //    public string? ContentAr { get; set; }
    //    [TranslateDisplay("English Content")]
    //    public string? ContentEn { get; set; }
    //    [TranslateDisplay("File")]
    //    public IFormFile? File { get; set; }
    //    [TranslateDisplay("File")]
    //    public string? FileId { get; set; }
    //    public string? PostId { get; set; }
    //}
}
