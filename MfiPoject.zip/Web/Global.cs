﻿global using Infrastructure;
global using Infrastructure.Services.Contracts;
global using Microsoft.AspNetCore.Mvc;
global using Infrastructure.Persistence;
global using Microsoft.EntityFrameworkCore;
global using FluentValidation;
global using FluentValidation.AspNetCore;
global using Infrastructure.Dtos.User;
global using Microsoft.AspNetCore.Authorization;

