﻿global using Infrastructure;

