﻿

namespace Core.Enums
{
	public enum PostType
	{
		News=0, Protocols=1, Achievements=2, Service=3
	}
}
