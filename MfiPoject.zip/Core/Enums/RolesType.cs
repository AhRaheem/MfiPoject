﻿

namespace Core.Enums
{
	public enum RolesType
	{
		Admin,
		NewsEditor,
		NewsPublisher,
		GalleryEditor,
		GalleryPublisher
	}
}
