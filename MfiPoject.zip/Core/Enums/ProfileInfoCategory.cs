﻿

namespace Core.Enums
{
	public enum ProfileInfoCategory
	{
		Phone,
		Email,
		Fax,
		Address,
		BankAccountNumber,
		SocialMedia
	}
}
