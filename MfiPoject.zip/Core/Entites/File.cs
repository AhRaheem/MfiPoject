﻿

namespace Core.Entites
{
	public class File : BaseEntity
	{
		public string? Extention { get; set; }
		public string? Content { get; set; }
		public string? Name { get; set; }
	}
}
