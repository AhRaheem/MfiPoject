﻿

namespace Core.Entites
{
	public class RelatedWebsite : BaseEntity
	{
		public string? FileId { get; set; }

		public string? NameAr { get; set; }
		public string? NameEn { get; set; }
		public string? Link { get; set; }
	}
}
