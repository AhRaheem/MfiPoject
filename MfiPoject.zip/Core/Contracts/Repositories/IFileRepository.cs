﻿


namespace Core.Contracts.Repositories
{
	public interface IFileRepository : IGenericRepository<IFileDbContext,Core.Entites.File>
	{
	}
}
