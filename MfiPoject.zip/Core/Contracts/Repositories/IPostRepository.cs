﻿using Core.Entites.Base;
using Core.Models;
using Core.Persistence;

namespace Core.Contracts.Repositories
{
 //   public interface IPostRepository : IGenericRepository<IApplicationDbContext, Post>
	//{
 //       Task CreatePostParagraph(PostArticlePostParagraph Entity);

 //       Task UpdatePostParagraph(PostArticlePostParagraph Entity);

 //       Task DeletePostParagraph(PostArticlePostParagraph Entity);

 //       Task SortPostParagraphs(List<SortModel> Entities);

 //       Task<IEnumerable<PostArticlePostParagraph>> GetParagraphs(string PostId);

 //       Task<PostArticlePostParagraph> GetParagraphById(string Id);
 //       Task<PostArticlePostParagraph> GetParagraphByNameAr(string Name);
 //       Task<PostArticlePostParagraph> GetParagraphNameEn(string Name);



 //       Task CreatePostAffiliateLaw(PostAffiliateLaw Entity);

 //       Task UpdatePostAffiliateLaw(PostAffiliateLaw Entity);

 //       Task DeletePostAffiliateLaw(PostAffiliateLaw Entity);

 //       Task SortPostAffiliateLaws(List<SortModel> Entities);

 //       Task<IEnumerable<PostAffiliateLaw>> GetAffiliateLaws(string PostId);

 //       Task<PostAffiliateLaw> GetAffiliateLawById(string Id);
 //       Task<PostAffiliateLaw> GetAffiliateLawByNameEn(string Name);
 //       Task<PostAffiliateLaw> GetAffiliateLawByNameAr(string Name);
 //   }
}
