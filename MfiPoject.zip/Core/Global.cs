﻿global using Core.Entites;
global using Core.Contracts.Repositories;
global using Core.Contracts.UnitOfWork;
global using AutoMapper;
global using Core.Entities.Base;
global using Core.Enums;
global using System.ComponentModel.DataAnnotations.Schema;
global using Microsoft.EntityFrameworkCore;
global using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
global using Microsoft.AspNetCore.Identity;
global using Core.Persistence;


